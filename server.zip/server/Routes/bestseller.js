const bestseller = require('../Model/bestseller'); // Change 'product' to 'bestseller'
const express = require('express');
const router = express.Router();

// Get all bestsellers
router.get('/', async (req, res) => {
  try {
      const bestseller = await bestseller.find({});
      res.json(bestseller);
  } catch (err) {
    console.error("Error fetching bestsellers:", err);
      res.status(500).json({ message: "Internal Server Error" });
  }
});

// Create a new bestseller
router.post('/create', async (req, res) => {
    console.log(req.body);

  try {
    const newBestseller = await bestseller(req.body).save();

    res.send(newBestseller);

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Internal Server Error" });
  }
});

module.exports = router;
